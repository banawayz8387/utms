/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
// utms/transport/interfaces/Trackable.java
package utms.interfaces;

public interface Trackable {
    void track();
}
